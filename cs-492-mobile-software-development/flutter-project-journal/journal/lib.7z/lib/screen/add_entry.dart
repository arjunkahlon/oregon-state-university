import 'package:flutter/material.dart';
import 'package:journal/model/journal_entry.dart';
import 'package:journal/db/service_entry.dart';

class AddEntry extends StatelessWidget {
  TextEditingController titleController = TextEditingController();
  TextEditingController bodyController = TextEditingController();
  TextEditingController ratingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Entry'),
        centerTitle: true,
      ),
      body: Form(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              TextFormField(
                controller: titleController,
                decoration: InputDecoration(labelText: 'Title'),
              ),
              SizedBox(height: 15,),
              TextFormField(
                controller: bodyController,
                decoration: InputDecoration(labelText: 'Body'),
                maxLines: null,
              ),
              SizedBox(height: 15,),
              TextFormField(
                controller: ratingController,
                decoration: InputDecoration(labelText: 'Rating'),
              ),
              SizedBox(height: 15,),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  RaisedButton(child: Text('Cancel'),onPressed: (){}),
                  SizedBox(width: 50,),
                  RaisedButton(child: Text('Add'),onPressed: (){
                    saveEntry(titleController.text, bodyController.text, ratingController.text);
                    Navigator.pop(context);
                  }),

                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void saveEntry(String title, String body, String rating) {
    JournalEntry journalEntry = JournalEntry(null, title, body, int.parse(rating), DateTime.now());
    ServiceEntry.addEntry(journalEntry);
  }
}
