import 'package:flutter/material.dart';

class ViewEntry extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
