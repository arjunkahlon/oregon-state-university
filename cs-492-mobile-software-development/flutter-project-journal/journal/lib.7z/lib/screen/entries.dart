import 'package:flutter/material.dart';
import 'package:journal/model/journal_entry.dart';
import 'package:journal/db/service_entry.dart';

class Entries extends StatefulWidget {
  Future<List<JournalEntry>> futureJournalEntries;


  Entries(this.futureJournalEntries);

  @override
  _EntriesState createState() => _EntriesState();
}

class _EntriesState extends State<Entries> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    widget.futureJournalEntries = ServiceEntry.retrieveEntries();
  }
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(future: widget.futureJournalEntries,builder: (context, snapshot) {
      if (snapshot.hasData) {
        List<JournalEntry> journalEntries = snapshot.data;
        return buildEntriesView(journalEntries);
      } else {
        return Center(
          child: CircularProgressIndicator(),
        );
      }
    });
  }

  Widget buildEntriesView(List<JournalEntry> journalEntries) {
    if (journalEntries.length == 0) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.book,
              size: 80,
            ),
            Text('Select Plus to Add Entry'),
          ],
        ),
      );
    } else {
      return ListView.builder(
          itemCount: journalEntries.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(journalEntries[index].title),
              subtitle: Text(
                journalEntries[index].date.toIso8601String(),
              ),
            );
          });
    }
  }
}
